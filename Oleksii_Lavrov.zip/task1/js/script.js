let burgerMenu = document.querySelector('.burger__menu');

document.querySelector('.burger').addEventListener('click', function () {
   document.querySelector('.burger span').classList.toggle('active');
   burgerMenu.classList.toggle('active');
})



const swiper = new Swiper('.swiper', {
   // Optional parameters
   direction: 'horizontal',
   // loop: true,
   pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
   },

   navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
   },

   // And if we need scrollbar
   scrollbar: {
      el: '.swiper-scrollbar',
   },

   simulateTouch: true,
   touchRatio: 1,
   slidesPerView: 1,
   spaceBetween: 120,
   initialSlide: 0,
   centeredSlide: true,

   autoplay: {
      delay: 10 * 000,
      stopOnLastSlide: true,
      disableOnInteraction: false,
   }
});


let comments = [
   {
      name: 'Nate Davidsson',
      title: 'We had an amazing stay at the Guest House!',
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.',
   },
   {
      name: 'Laura Paulie',
      title: 'Beautiful little hideaway.',
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet.',
   },
   {
      name: 'Chirs Smith',
      title: 'Unbelievable time spending.',
      text: 'Lorem ipsum dolor sit amet, arius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet.',
   },
]

let commentText = document.querySelectorAll('.comment__text');
let commentTitle = document.querySelectorAll('.comment__title');
let commentAuthor = document.querySelectorAll('.comment__author');
let commentsSlide = document.querySelectorAll('.comments__swiper-slide');
let commentRateImg = document.querySelectorAll('.comment__rate-img'); //array of images in HTML
let commentAttr = [];
for (let i = 0; i < commentsSlide.length; i++) {
   commentAttr.push(commentsSlide[i].getAttribute('data-comment-author'));
}
for (let i = 0; i < commentAttr.length; i++) {
   commentTitle[i].innerHTML = comments[i].title;
   commentText[i].innerHTML = comments[i].text;
   commentAuthor[i].innerHTML = comments[i].name;
}

