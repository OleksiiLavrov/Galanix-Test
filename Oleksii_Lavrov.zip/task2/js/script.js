const gridItems = document.querySelectorAll('.grid-box__item'); // array of grid items
const closeBtns = document.querySelectorAll('.closeBtn');      // array of btns to hide items
const gridBox = document.querySelector('.grid-box');           // grid box list
const restoreBtn = document.getElementById('restore');         // restore btn
const popup = document.querySelector('.popup');                // popup block
const popupCloseBtn = document.querySelector('.popup__close');   // close popup btn
const gridItemsImg = gridBox.getElementsByTagName('img');        // list of all images in grid box list

let counterText = document.getElementById('counter');
let storage = [];                                     // storage for hiden files
let counter = gridItems.length;                       // counter value depends on amount of grid items 
counterText.innerHTML = `Current amount of photos: ${counter}`;

currentTime();
giveIds()

function giveIds() { // setting ids for each grid item
   for (let i = 0; i < gridItems.length; i++) {
      gridItems[i].setAttribute('id', i + 1);
   }
}
function openPopup(id) {            // opening popup block 
   popup.style.display = 'block';   // making popup visible
   document.body.style.overflowY = 'hidden';    // blocking body scroll
   let popupImg = document.createElement("img");   // creating new HTML elem
   popupImg.className = 'popup__img';              // setting class and attribute
   popupImg.setAttribute('src', `./img/${id + 1}.jpg`);
   popup.prepend(popupImg);                        // installing HTML elem into DOM
}
function closePopup() {             // close popup
   popup.style.display = 'none';    // making popup invisible
   document.body.style.overflowY = 'visible';   // return scroll
   popup.querySelector('.popup__img').remove(); // removing from DOM
}
function restoreItems() {           // restoring hiden items back
   for (let i = 0; i < gridItems.length; i++) {
      for (let j = 0; j < storage.length; j++) {
         if (gridItems[i].getAttribute('id') === storage[j].getAttribute('id')) {   // comparing ids of elems
            gridBox.prepend(gridItems[i]);                  // installing HTML elem into DOM
         }
      }
   }
   counter = gridItems.length;                  // reseting counter to default
   counterText.innerHTML = `Current amount of photos: ${counter}`;
}
function currentTime() {            // getting date
   let now = new Date();
   let month = now.getMonth() + 1;
   let date = now.getDate();
   let year = now.getFullYear();
   let hours = now.getHours();
   let minutes = now.getMinutes();
   month = checkTimeValue(month);
   date = checkTimeValue(date);
   minutes = checkTimeValue(minutes);
   document.getElementById('date').innerHTML = `${date}.${month}.${year} ${hours}:${minutes}`;
   timer = setTimeout('currentTime()', 1000);   // getting fresh info each second
};
function checkTimeValue(data) {  // changing format of date(time) if the number less than 10
   if (data < 10) {
      data = "0" + data;
   }
   return data;
};

gridBox.addEventListener('click', (event) => {     // adding one event listener and get target of the event

   for (let i = 0; i < closeBtns.length; i++) {
      if (event.target === closeBtns[i]) {         // comparing event.target and array of btns
         storage.push(gridItems[i]);               // push hiden grid item to storage
         gridItems[i].remove();                    // removing hiden grid item from DOM
         counter--;
         counterText.innerHTML = `Current amount of photos: ${counter}`;
         closePopup(i)
      }

      if (event.target.parentNode.parentNode === gridItems[i]) {     // comparing event.target and array of grid items
         openPopup(i);
      }
   }
});

popupCloseBtn.addEventListener('click', closePopup);

restoreBtn.addEventListener('click', restoreItems);





