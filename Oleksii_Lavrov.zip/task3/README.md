# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## HOW TO OPEN PROJECT

In the project directory, you should run:
### `npm i` to install node_modules
### `npm start` to start project

The page will reload when you make changes.\
You may also see any lint errors in the console.

