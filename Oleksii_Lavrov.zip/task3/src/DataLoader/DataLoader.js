import React, { Component } from "react";

import './DataLoader.css';

export default class DataLoader extends Component {
   constructor() {
      super();

      this.state = {
         apiData: [],             // state for getting data from api
         checkBoxCounter: 0,      // counter
         textFormat: 'university!', // state depens on counter value
         textError: '',          // state value of error
         defaultInputVal: '',    // state default value of input
      };
      this.inputDataVal = React.createRef(); //
   }

   getData = () => {  // function for getting data and setting to states
      document.querySelector('.error').style.display = 'none';  // hiding error if it was called
      if (this.inputDataVal.current.value !== '') {             // checking if input is not empty
         localStorage.setItem('inputVal', `${this.inputDataVal.current.value}`);    // saving input value to local storage
         fetch(`http://universities.hipolabs.com/search?country=${this.inputDataVal.current.value}`)
            .then(response => response.json())
            .then(data => {
               if (data.length === 0) {
                  this.setState({ textError: `*Name of country is incorrect` });   // error will apear if data from api will be empty
                  document.querySelector('.error').style.display = 'block';    // show error
               } else {
                  this.setState({ apiData: data });      // setting data to apiData state
                  localStorage.setItem('data', `${data.length}`);    // saving length of data array to local storage
               }
            });

      } else {
         this.setState({ textError: `*Input can't be blanked` });   // error will apear if input is blanked
         document.querySelector('.error').style.display = 'block';  // show error
      }
   }
   resetData = () => { // function for reseting data and states
      document.getElementById('table').style.display = 'none';          // hide table
      document.querySelector('.textCounter').style.display = 'none';    // hide counter
      this.setState({ apiData: [] });        // setting default data to states
      this.setState({ checkBoxCounter: 0 });

      this.inputDataVal.current.value = '';  // blanking input
      localStorage.clear();                  // clear storage
   }
   checkBoxCount = (event) => { // function for counting the checkboxes
      let counter = this.state.checkBoxCounter;
      if (event.target.checked === true) { // checking state of checkbox
         counter++;
         if (counter > 0) {
            document.querySelector('.textCounter').style.display = 'block'; // show counter after 0 value
            if (counter > 1) {
               this.setState({ textFormat: 'universities!' });  // change word after counter value = 1
            }
         }
      } else {
         counter--;

         if (counter === 1) {
            this.setState({ textFormat: 'university!' }); // change word if counter value = 1
         }
         if (counter === 0) {
            document.querySelector('.textCounter').style.display = 'none'; // hide counter if 0 value
         }
      }

      this.setState({ checkBoxCounter: counter });       // setting counter to checkBoxCounter state
      localStorage.setItem('counter', `${counter}`);     // saving info about counter to local storage
   }
   componentDidUpdate() {  // method works when component was updated
      if (this.state.apiData.length !== 0) {
         document.getElementById('table').style.display = 'block'; // show table only after getting all info
      }
   }
   componentDidMount() { // method works when component was mounted
      if (Number(localStorage.getItem('data')) > 0) {           // this function works only for reloaded page
         let counter = Number(localStorage.getItem('counter')); // getting data from local storage
         let inputVal = localStorage.getItem('inputVal');

         this.setState({ checkBoxCounter: counter });       // setting data from local storage to states
         this.setState({ defaultInputVal: inputVal });
         fetch(`http://universities.hipolabs.com/search?country=${inputVal}`) // getting data from api after reloading the page 
            .then(response => response.json())
            .then(data => {
               this.setState({ apiData: data });
            });
         if (counter > 0) {
            document.querySelector('.textCounter').style.display = 'block';      // show counter
         }
      }
   }

   render() {
      return (
         <div className="DataLoader">

            <input type="text" className="input" placeholder="Country"
               defaultValue={this.state.defaultInputVal} ref={this.inputDataVal} />
            <button className="btn" onClick={this.getData}>Send</button>
            <button className="btn" onClick={this.resetData}>Reset</button>
            <p className="error">{this.state.textError}</p>
            <p className="textCounter">You have chosen {this.state.checkBoxCounter} {this.state.textFormat}</p>
            <table id="table">
               <tbody>
                  <tr>
                     <th>Number</th>
                     <th>Alpha two code</th>
                     <th>Country</th>
                     <th>Domain</th>
                     <th>Name</th>
                     <th>Web page</th>
                     <th>Save to my list</th>
                  </tr>
                  {this.state.apiData.map((item, index) =>  // map the array with data and render all rows 
                     <tr key={index + 1}>
                        <td>{index + 1}</td>
                        <td>{item.alpha_two_code}</td>
                        <td>{item.country}</td>
                        <td>{item.domains[0]}</td>
                        <td>{item.name}</td>
                        <td><a href={item.web_pages[0]}>{item.web_pages[0]}</a></td>
                        <td><input id={index + 1} type="checkbox" className="checkBox" onChange={this.checkBoxCount} /></td>
                     </tr>
                  )}
               </tbody>
            </table>
         </div>
      );
   }
}