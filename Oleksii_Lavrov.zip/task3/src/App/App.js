import DataLoader from '../DataLoader/DataLoader';

import './App.css';

function App() {
  return (

    <>
      <DataLoader />
    </>
  );
}

export default App;
